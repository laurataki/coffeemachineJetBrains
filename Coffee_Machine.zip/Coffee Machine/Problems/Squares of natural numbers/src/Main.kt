import kotlin.math.sqrt

fun main() {
    val nN = readLine()!!.toDouble()
    var i = 1
    while (i <= sqrt(nN)) {
        println(i * i)
        i = i.inc()
    }
}