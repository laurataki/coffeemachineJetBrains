fun main() {
    val words = readLine()!!
    val number = readLine()!!.toInt()
    println("Symbol # $number of the string \"$words\" is '${words[number - 1]}'") }
