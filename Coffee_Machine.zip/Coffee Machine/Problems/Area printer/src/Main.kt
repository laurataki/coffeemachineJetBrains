class Rectangle(val width: Int, val height: Int)

fun printArea(rectangle: Rectangle) {
    println(rectangle.width * rectangle.height)
}
