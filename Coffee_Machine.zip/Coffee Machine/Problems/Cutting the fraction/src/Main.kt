import java.util.Scanner
fun main() {
    val scanner = Scanner(System.`in`)
    val input = scanner.nextDouble()
    val output = input.toLong()
    println(output)
}
