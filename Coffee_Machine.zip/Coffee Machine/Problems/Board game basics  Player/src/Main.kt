import kotlin.random.Random

class Player(val id: Int, val name: String, val hp: Int = 100) {

    companion object {
        fun create(name: String): Player {
            var id: Int = Random.nextInt()
            var hp = 100
            return Player(id, name, hp)
        }
    }
}