fun main() {
    val a = readLine()!!.toInt()
    val b = readLine()!!.toInt()
    println("$a plus $b equals ${a+b}")
}