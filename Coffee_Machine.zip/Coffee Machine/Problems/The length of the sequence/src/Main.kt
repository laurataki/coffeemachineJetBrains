fun main() {
    var sequenceLength = 0
    while (readLine()!!.toInt() > 0) {
        sequenceLength++
    }
    println(sequenceLength)
}
