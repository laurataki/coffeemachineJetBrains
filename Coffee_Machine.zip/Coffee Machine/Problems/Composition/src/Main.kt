class OperatingSystem {
    var name: String = "hi"
}
class DualBoot {
    var primaryOs: OperatingSystem = TODO()
    var secondaryOs: OperatingSystem = TODO()
}
fun main() {
    var firstObject = OperatingSystem()
    var secondObject = DualBoot()
}