import java.util.Scanner

enum class CountryCurrencies(val nName: String, val currency: String) {
    Germany("Germany", "Euro"),
    Mali("Mali", "CFA franc"),
    Dominica("Dominica", "Eastern Caribbean dollar"),
    Canada("Canada", "Canadian dollar"),
    Spain("Spain", "Euro"),
    Australia("Australia", "Australian dollar"),
    Brazil("Brazil", "Brazilian real"),
    Senegal("Senegal", "CFA franc"),
    France("France", "Euro"),
    Grenada("Grenada", "Eastern Caribbean dollar"),
    Kiribati("Kiribati", "Australian dollar"),
    NULL("nothing", "nothing");

    companion object {
        fun findCountry(input: String): CountryCurrencies {
            for (enum in values()) {
                if (input == enum.name) return enum
            }
            return NULL
        }
    }
}
fun main() {
    val scanner = Scanner(System.`in`)
    val country1 = scanner.next()
    val country2 = scanner.next()
    val result: Boolean = CountryCurrencies.findCountry(country1).currency == CountryCurrencies.findCountry(country2).currency
            && !(CountryCurrencies.findCountry(country1).nName == "nothing" && CountryCurrencies.findCountry(country2).nName == "nothing")
    println(result)
}