import java.util.Scanner

fun main(args: Array<String>) {

 var scanner = Scanner(System.`in`)
    val population = scanner.nextInt()
 var assemblySize = Math.cbrt(population.toDouble())
    println(assemblySize.toInt())
}
