import kotlin.math.pow

fun finalAmount(amount: Double = 1000.0, percent: Double = 5.0, years: Double = 10.0): Double {
    return amount * (1.0 + percent / 100.0).pow(years)
}

fun main() {
    val namedArgument = readLine()!!
    val value = readLine()!!.toInt()
    val moneyz = when (namedArgument) {
        "amount" -> {
            finalAmount(amount = value.toDouble())
        }
        "percent" -> {
            finalAmount(percent = value.toDouble())
        }
        "years" -> {
            finalAmount(years = value.toDouble())
        }
        else -> finalAmount(1000.0, 5.0, 10.0)
    }
    println(moneyz.toInt())
}
