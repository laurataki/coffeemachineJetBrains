import java.util.Scanner

fun isVowel(letter: Char): Boolean {
    val vowels = charArrayOf('a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U')
    val result: Boolean
    val scanner = Scanner(System.`in`)
    val letter: Char = scanner.next().single()
    result = vowels.contains(element = letter)
    return result
    }

fun main() {

    val letter = readLine()!!.first()

    println(isVowel(letter))
}
