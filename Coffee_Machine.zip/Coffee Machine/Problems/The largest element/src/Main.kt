import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)
    var largestNum = 1
    do {
        largestNum = scanner.nextInt()
    }
    while (scanner.hasNextInt() && (largestNum < scanner.nextInt()))

    println(largestNum)

}