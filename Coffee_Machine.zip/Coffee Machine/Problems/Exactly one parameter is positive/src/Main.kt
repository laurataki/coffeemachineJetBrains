import kotlin.math.abs

fun main() {
    val a = readLine()!!.toInt()
    val b = readLine()!!.toInt()
    val c = readLine()!!.toInt()

    if (a + b + c == c - abs(a) - abs(b) && c > 0) {
        println("true")
    } else if (a + b + c == b - abs(a) - abs(c) && b > 0) {
        println("true")   
    } else if (a + b + c == a - abs(c) - abs(b) && a > 0) {
        println("true")   
    } else println("false")
}
