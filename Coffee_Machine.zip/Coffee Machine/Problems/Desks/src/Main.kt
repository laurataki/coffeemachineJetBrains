fun main() {
    val a = readLine()!!.toInt()
    val b = readLine()!!.toInt()
    val c = readLine()!!.toInt()
    var desk = 0
    if (a % 2 == 0) {
        desk += a / 2
    } else desk += a / 2 + 1

    if (b % 2 == 0) {
        desk += b / 2
    } else desk += b / 2 + 1

    if (c % 2 == 0) {
        desk += c / 2
    } else desk += c / 2 + 1

    println(desk)
}
