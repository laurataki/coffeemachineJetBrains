fun carPrice(old: Int = 5, passed: Int = 100_000, speed: Int = 120, auto: Int = 0): Int {
    var price: Double = 20_000.0
    if (auto == 1) {
        price = 20_000 - old * 2000 - (120 - speed) * 100 - (passed - passed % 10_000) * 0.02 + 1500
        } else price = (20_000 - old * 2000 - (120 - speed) * 100 - (passed - passed % 10_000) * 0.02).toDouble()
                return price.toInt() }
fun main(args: Array<String>) {
    val namedArgument = readLine()!!
    val value = readLine()!!.toInt()
    val price = if (namedArgument == "old") {
        carPrice(old = value)
    } else if (namedArgument == "passed") {
        carPrice(passed = value)
    } else if (namedArgument == "speed") {
        carPrice(speed = value)
    } else if (namedArgument == "auto") {
        carPrice(auto = value)
    } else carPrice(5, 100_000, 120, 0)
    println(price)
}
