import java.util.Scanner

enum class Rainbow(val color: String) {
    RED("red"),
    BLUE("blue"),
    YELLOW("yellow"),
    ORANGE("orange"),
    GREEN("green"),
    VIOLET("violet"),
    INDIGO("indigo");

    companion object {
        fun findColor(input: String): Boolean {
            for (enum in values()) {
                if (input == enum.color) return true
            }
            return false
        }
    }
}
fun main() {
    val scanner = Scanner(System.`in`)
    val colorino = scanner.next()
    println(Rainbow.findColor(colorino))
}