fun main() {
    val n = readLine()!!.toInt()
    var i = 1

    val listy = mutableListOf<Int>()
    while (i <= n) {
        repeat(n - (n - i)) { listy.add(n - (n - i))
        }
        i++
    }
    listy.sort()
    var theIndex = 0
    while (theIndex < n) {
        print("${listy[theIndex]} ")
        theIndex++
    }
}
