fun main() {
    val input = readLine()!!
    if (input != "" && input[0] == 'i') {
       println(input.drop(1).toInt() + 1)
    }
    else if (input != "" && input[0] == 's') {
       println(input.drop(1).reversed())
    }
    else if (input.isEmpty()) {
        println()
    }
    else {println(input)}
}
