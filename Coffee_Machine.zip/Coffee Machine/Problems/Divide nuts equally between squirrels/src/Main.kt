fun main() {
    val n = readLine()!!.toInt()
    val k = readLine()!!.toInt()

    var divide = k / n
    println(divide)
}