class Cell {
    object BaseProperties {
        var width = 10
        var height = 10
    }
    var newWidth = BaseProperties.width
    var newHeight = BaseProperties.height
}
