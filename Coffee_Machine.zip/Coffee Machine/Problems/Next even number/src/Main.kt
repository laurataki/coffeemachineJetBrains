fun main() {
    val number = readLine()!!.toInt()
    if((number+1) % 2 == 0) {
        println(number+1)
    } else println(number+2)
}